/*
 * package com.sp.repositoryImpl;
 * 
 * import java.util.List;
 * 
 * import org.hibernate.Session; import org.hibernate.SessionFactory; import
 * org.hibernate.query.NativeQuery; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Repository;
 * 
 * import com.sp.entity.InvoiceMaster; import com.sp.repository.InvoiceBillRepo;
 * 
 * @Repository public class InvoiceBillRepoImpl {
 * 
 * @Autowired SessionFactory sessionfactory;
 * 
 * @Override public List<InvoiceMaster> getbilldata(Integer invoiceNo) {
 * 
 * String sql =
 * "select * from t2t_test.invoice_master where invoice_no="+invoiceNo; Session
 * session = sessionfactory.getCurrentSession(); NativeQuery<InvoiceMaster>
 * query = session.createNativeQuery(sql,InvoiceMaster.class);
 * List<InvoiceMaster> master = query.getResultList(); return master ; }
 * 
 * @Override public void saveInvoiceData(InvoiceMaster invoiceMaster) { Session
 * session = sessionfactory.getCurrentSession();
 * session.saveOrUpdate(invoiceMaster);
 * 
 * }
 * 
 * }
 */
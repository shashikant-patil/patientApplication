package com.sp.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="ambulance_patient")
public class AmbulancePatient {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	@Column(name="patient_id")
	private Long patientId;
	
	@Column(name="patient_name")
	private String patientName;
	
	@Column(name="mobile_no")
	private Long mobileNo;
	
	@Column(name="patient_addrs")
	private String patientAddrs;
	
	@Column(name="ambulance_no")
	private String ambulanceNo;
	
	@Column(name="driver_name")
	private String driverName;
	
	@Column(name="schedule_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDateTime scheduleDate;
	
	@Column(name="arrive_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDateTime arriveDate;
	
	@Column(name="drop_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDateTime dropDate;
	
	@Column(name="nurse_name")
	private String nurseName;
	
	@Column(name="hospital_id")
	private Integer hospitalId;
	
	@Column(name= "hospital_addrs")
	private String hospitalAdress;

	//get set method
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public Long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getPatientAddrs() {
		return patientAddrs;
	}

	public void setPatientAddrs(String patientAddrs) {
		this.patientAddrs = patientAddrs;
	}

	public String getAmbulanceNo() {
		return ambulanceNo;
	}

	public void setAmbulanceNo(String ambulanceNo) {
		this.ambulanceNo = ambulanceNo;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public LocalDateTime getScheduleDate() {
		return scheduleDate;
	}

	public void setScheduleDate(LocalDateTime scheduleDate) {
		this.scheduleDate = scheduleDate;
	}

	public LocalDateTime getArriveDate() {
		return arriveDate;
	}

	public void setArriveDate(LocalDateTime arriveDate) {
		this.arriveDate = arriveDate;
	}

	public LocalDateTime getDropDate() {
		return dropDate;
	}

	public void setDropDate(LocalDateTime dropDate) {
		this.dropDate = dropDate;
	}

	public String getNurseName() {
		return nurseName;
	}

	public void setNurseName(String nurseName) {
		this.nurseName = nurseName;
	}

	public Integer getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(Integer hospitalId) {
		this.hospitalId = hospitalId;
	}

	public String getHospitalAdress() {
		return hospitalAdress;
	}

	public void setHospitalAdress(String hospitalAdress) {
		this.hospitalAdress = hospitalAdress;
	}

	@Override
	public String toString() {
		return "AmbulancePatient [id=" + id + ", patientId=" + patientId + ", patientName=" + patientName
				+ ", mobileNo=" + mobileNo + ", patientAddrs=" + patientAddrs + ", ambulanceNo=" + ambulanceNo
				+ ", driverName=" + driverName + ", scheduleDate=" + scheduleDate + ", arriveDate=" + arriveDate
				+ ", dropDate=" + dropDate + ", nurseName=" + nurseName + ", hospitalId=" + hospitalId
				+ ", hospitalAdress=" + hospitalAdress + ", getId()=" + getId() + ", getPatientId()=" + getPatientId()
				+ ", getPatientName()=" + getPatientName() + ", getMobileNo()=" + getMobileNo() + ", getPatientAddrs()="
				+ getPatientAddrs() + ", getAmbulanceNo()=" + getAmbulanceNo() + ", getDriverName()=" + getDriverName()
				+ ", getScheduleDate()=" + getScheduleDate() + ", getArriveDate()=" + getArriveDate()
				+ ", getDropDate()=" + getDropDate() + ", getNurseName()=" + getNurseName() + ", getHospitalId()="
				+ getHospitalId() + ", getHospitalAdress()=" + getHospitalAdress() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	
	
}

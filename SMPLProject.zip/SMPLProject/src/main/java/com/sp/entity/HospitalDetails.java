package com.sp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hospital_details")
public class HospitalDetails {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	@Column(name="hospital_name")
	private String hospitalName;
	
	@Column(name="hospital_addrs")
    private String hospitalAddress;
	
	@Column(name="distname")
	private String distName;
	
	@Column(name="doctor_id")
	private Integer doctorId;
	
	@Column(name="doctor_name")
	private String doctorName;
	
	@Column(name="ambulance_no")
	private String ambulanceNo;
	
	@Column(name="nurse_id")
	private String nurseId;
	
	@Column(name = "nurse_name")
	private String nurseName;

//get set  	
	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getHospitalName() {
		return hospitalName;
	}


	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}


	public String getHospitalAddress() {
		return hospitalAddress;
	}


	public void setHospitalAddress(String hospitalAddress) {
		this.hospitalAddress = hospitalAddress;
	}


	public String getDistName() {
		return distName;
	}


	public void setDistName(String distName) {
		this.distName = distName;
	}


	public Integer getDoctorId() {
		return doctorId;
	}


	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}


	public String getDoctorName() {
		return doctorName;
	}


	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}


	public String getAmbulanceNo() {
		return ambulanceNo;
	}


	public void setAmbulanceNo(String ambulanceNo) {
		this.ambulanceNo = ambulanceNo;
	}


	public String getNurseId() {
		return nurseId;
	}


	public void setNurseId(String nurseId) {
		this.nurseId = nurseId;
	}


	public String getNurseName() {
		return nurseName;
	}


	public void setNurseName(String nurseName) {
		this.nurseName = nurseName;
	}


	//to string 
	@Override
	public String toString() {
		return "HospitalDetails [id=" + id + ", hospitalName=" + hospitalName + ", hospitalAddress=" + hospitalAddress
				+ ", distName=" + distName + ", doctorId=" + doctorId + ", doctorName=" + doctorName + ", ambulanceNo="
				+ ambulanceNo + ", nurseId=" + nurseId + ", nurseName=" + nurseName + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	
	
}

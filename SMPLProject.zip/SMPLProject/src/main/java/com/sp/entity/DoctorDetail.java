package com.sp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="doctor_detail")
public class DoctorDetail {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	@Column(name="doctor_name")
	private String doctorName;
	
	@Column(name="doc_addrs")
	private String docAddress;
	
	@Column(name="doc_degree")
	private String degree;
	
	@Column(name="hospital_id")
	private Long hospitalId;
	
	@Column(name="hospital_name")
	private String hospitalName;
	
	
	@Column(name="created_date")
	private String createdDate;
	
	@Column(name="updated_date")
	private String updateDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getDocAddress() {
		return docAddress;
	}

	public void setDocAddress(String docAddress) {
		this.docAddress = docAddress;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public Long getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(Long hospitalId) {
		this.hospitalId = hospitalId;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	@Override
	public String toString() {
		return "DoctorDetail [id=" + id + ", doctorName=" + doctorName + ", docAddress=" + docAddress + ", degree="
				+ degree + ", hospitalId=" + hospitalId + ", hospitalName=" + hospitalName + ", createdDate="
				+ createdDate + ", updateDate=" + updateDate + ", getId()=" + getId() + ", getDoctorName()="
				+ getDoctorName() + ", getDocAddress()=" + getDocAddress() + ", getDegree()=" + getDegree()
				+ ", getHospitalId()=" + getHospitalId() + ", getHospitalName()=" + getHospitalName()
				+ ", getCreatedDate()=" + getCreatedDate() + ", getUpdateDate()=" + getUpdateDate() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	
	

}

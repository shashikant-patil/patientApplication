
package com.sp.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

 import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sp.beans.PatientDetailBean;
import com.sp.entity.PatientDetails;
import com.sp.service.PatientInfoService;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Controller

@RequestMapping("/patientinfo")
public class PatientInfoController {

	@Autowired
	PatientInfoService service;

	 // for save form
	@RequestMapping("/saveform")
	public String saveform(Model model) {  
        model.addAttribute("patientDetails", new PatientDetails());
		return "patientsave";
	}
	
	//save in DB
	 @PostMapping("/savePatient")
	    public String savePatient(@ModelAttribute("patientDetails") PatientDetails patientDetails ,Model model) {
		 PatientDetails patientDetail  = new PatientDetails();
		   patientDetail = service.savePatient(patientDetails);
		   
		 String patientno =null;
		 if(patientDetail.getPatientId()!=null) {
			 patientno=patientDetail.getPatientNo();
			 model.addAttribute("patientId", patientDetail.getPatientId());
			    model.addAttribute("patientNo", patientDetail.getPatientNo());
		 }else {
			 
		 }
	        return "redirect:/patientinfo/saveform?success=true";
	    }
	 

	 //for edit form
	  @RequestMapping("/edit")
	  public String editForm(Model model,@RequestParam("PatientId") Long patientId) {
		PatientDetails patientinfo = service.getbypatientId(patientId);
		 if (patientinfo != null) {
		        model.addAttribute("patientDetails", patientinfo);
		    } else {
		        model.addAttribute("errorMessage", "Patient not found!");
		    }
		  return "patientedit";
	  }

	  //for update edit form
	  @PostMapping("/updatePatient")
	  public String updatePatient(@ModelAttribute PatientDetails patientDetails , Model model) {
	      service.updatePatient(patientDetails);  
	      model.addAttribute("patientId", patientDetails.getPatientId());
	      return "redirect:/patientinfo/edit?PatientId="+patientDetails.getPatientId();  
	  }
	  
	  
	@RequestMapping("/detail")
	public  String showPatientInfo(ModelMap model) {
		Iterable<PatientDetails> patientinfo = service.getAllPatient();
		
		model.put("list", patientinfo);
		return "patientInfo";

	}

	@RequestMapping("/report")
	public void getdata(HttpServletResponse resp) throws JRException, IOException {
		List<PatientDetailBean> list = service.getdata();

		HashMap<String, Object> reportParams = new HashMap<String, Object>();
		reportParams.put("reportname", "Patient Details Report");

		File reportFile = new File("path/to/your/report.jrxml");

		JasperReport jasperReport = JasperCompileManager.compileReport(reportFile.getAbsolutePath());

		JRBeanCollectionDataSource jrbean = new JRBeanCollectionDataSource(list);

		JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, reportParams, jrbean);

		resp.setContentType("application/pdf");
		ServletOutputStream ouputStream = resp.getOutputStream();
		JasperExportManager.exportReportToPdfStream(jasperPrint, ouputStream);
		ouputStream.flush();
		ouputStream.close();

	}

}

package com.sp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sp.entity.AmbulancePatient;
import com.sp.service.AmbulanceDetailService;

@Controller
@RequestMapping("/ambulance")
public class AmbulanceDetailsController {
	
	@Autowired
	AmbulanceDetailService service;
	
	@GetMapping("/form")
	public String ambulanceForm(Model model) {
		model.addAttribute("ambulancedetail",new AmbulancePatient());
		return "ambulancesave";
	}
	
	@PostMapping("/saveambulance")
	public String saveAmbulanceInfo(@ModelAttribute("ambulancedetail") AmbulancePatient ambulance) {
		AmbulancePatient details = new AmbulancePatient();
		details = service.savedata(ambulance);
		if (details!=null) {
			System.out.println("Saved successfull");
			
		}
 		return "redirect:/ambulance/form";
	}
	

}

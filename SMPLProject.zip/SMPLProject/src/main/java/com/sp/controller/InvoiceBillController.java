package com.sp.controller;

 
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sp.entity.InvoiceMaster;
import com.sp.service.InvoiceBillService;
 
@RestController
@RequestMapping("/bill")
public class InvoiceBillController {

	@Autowired
	InvoiceBillService invoiceBillService;
	
	
	
	  @GetMapping(value="/data") 
	  public InvoiceMaster getBillAllData(@RequestParam String invoiceNo){
		   InvoiceMaster data = invoiceBillService.getbilldata(invoiceNo); 
		  return  data; 
		  }
	  
	  @GetMapping
	    public List<InvoiceMaster> getAllInvoices() {
	        return invoiceBillService.findAll();
	    }
	 
	  @PostMapping("/save")
	    public ResponseEntity<InvoiceMaster> saveInvoice(@RequestBody InvoiceMaster invoiceMaster) {
	        InvoiceMaster savedInvoice = invoiceBillService.saveInvoice(invoiceMaster);
	        return ResponseEntity.ok(savedInvoice);   
	    }
	  
}

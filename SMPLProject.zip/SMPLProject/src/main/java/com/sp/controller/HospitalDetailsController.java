package com.sp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sp.entity.HospitalDetails;
import com.sp.entity.PatientDetails;
import com.sp.service.HospitalDetailsService;

@Controller
@RequestMapping("/hospital")
public class HospitalDetailsController {

	@Autowired
	HospitalDetailsService service;
	
	
	/*
	 * public String hospitalDetail(ModelAndView view) {
	 * view.addAttribute("patientDetails", new PatientDetails()); return
	 * "hospitaldetail"; }
	 */
	
	@GetMapping("/form")
	public ModelAndView hospitalDetail() {
	    ModelAndView view = new ModelAndView();
	    view.addObject("hospitaldetails", new HospitalDetails());
	    view.setViewName("hospitaldetail");
	    return view;
	}
	
	@PostMapping("/saveinfo")
	public String saveHospitalinfo(@ModelAttribute("hospitaldetails") HospitalDetails hospital) {
		HospitalDetails hospitalinfo =	service.savehospital(hospital);
		return  "redirect:/hospital/form";
	}
	
	
	/*
	 * @PostMapping("/save") public HospitalDetails saveHospital(HospitalDetails
	 * hospitalDetails){ HospitalDetails bean =
	 * service.savehospital(hospitalDetails); return bean ; }
	 */
}

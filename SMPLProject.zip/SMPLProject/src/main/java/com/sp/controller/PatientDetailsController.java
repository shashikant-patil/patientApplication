package com.sp.controller;

 
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sp.beans.PatientDetailBean;
import com.sp.entity.PatientDetails;
import com.sp.service.PatientDetailService;

@Controller
@RequestMapping("/patient")
public class PatientDetailsController {
	
	@Autowired
	PatientDetailService patientDetailService;
	
	@PostMapping("/savepatient")
	public ResponseEntity<PatientDetails>  savepatient(@RequestBody PatientDetails patientDetails){
		PatientDetails list = patientDetailService.saveDetails(patientDetails);
		return ResponseEntity.ok(list);
		
	}
	
	@GetMapping("/getdata")
	public ResponseEntity<PatientDetails> getPatientDetails(@RequestParam("patientId") Long patientId){
		PatientDetails singlelist = patientDetailService.findByPatientId(patientId);
		return  ResponseEntity.ok(singlelist);
	}

	
	@GetMapping("/getpatientdata/{patientNo}")
	public ResponseEntity<List<Map<String, Object>>> getPatientData(@PathVariable String patientNo) {
		List<Map<String, Object>> patientData = patientDetailService.getpatientdata(patientNo);
		return ResponseEntity.ok(patientData);
	}
	
}

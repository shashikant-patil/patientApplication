package com.sp.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sp.entity.AmbulancePatient;
import com.sp.repository.AmbulanceDetailRepo;
import com.sp.service.AmbulanceDetailService;

@Service
public class AmbulanceDetailServiceImpl implements AmbulanceDetailService{

	@Autowired
	AmbulanceDetailRepo repo;
	
	@Override
	public AmbulancePatient savedata(AmbulancePatient ambulancePatient) {
 		return repo.save(ambulancePatient);
	}

}

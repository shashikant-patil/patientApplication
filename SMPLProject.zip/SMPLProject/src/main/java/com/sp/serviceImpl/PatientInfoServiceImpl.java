package com.sp.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sp.beans.PatientDetailBean;
import com.sp.entity.PatientDetails;
import com.sp.repository.PatientInfoRepo;
import com.sp.service.PatientInfoService;

@Service
public class PatientInfoServiceImpl  implements PatientInfoService{

	@Autowired
	PatientInfoRepo info;
	
	@Override
	public Iterable<PatientDetails> getAllPatient() {
		 
		return info.findAll();
	}

	@Override
	public List<PatientDetailBean> getdata() {
		Iterable<PatientDetails> iterable =info.findAll();
		List<PatientDetailBean> listbean = new ArrayList<>();
	 
		iterable.forEach(patient ->{
			PatientDetailBean bean =new PatientDetailBean();
			bean.setPatientId(patient.getPatientId());
		    bean.setFname(patient.getFname());
		    bean.setMname(patient.getMname());
		    bean.setLname(patient.getLname());
		    bean.setCity(patient.getCity());
		    bean.setPincode(patient.getPincode());
		    bean.setAddress(patient.getAddress());
		    bean.setAge(patient.getAge());
		    bean.setDob(patient.getDob());
		    bean.setMobileNo(patient.getMobileNo());
		    bean.setGender(patient.getGender());
		    bean.setAdharNo(patient.getAdharNo());
		    bean.setHeight(patient.getHeight());
 		    bean.setPatientNo(patient.getPatientNo());
			listbean.add(bean);
		});
		
		return listbean ;
	}

	@Override
	public PatientDetails getbypatientId(Long patientId) {
		return info.findPatientById(patientId);
 	}

	@Override
	public PatientDetails savePatient(PatientDetails patientDetails) {
		PatientDetails list = new PatientDetails();
	//	list.setFname();
		 list = info.save(patientDetails);
		return list;
	}

	@Override
	public PatientDetails updatePatient(PatientDetails patientDetails) {
		
		return info.save(patientDetails);
	}

}

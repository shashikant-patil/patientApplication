package com.sp.serviceImpl;

 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sp.beans.PatientDetailBean;
import com.sp.entity.PatientDetails;
import com.sp.repository.PatientDetailRepo;
import com.sp.service.PatientDetailService;

@Service
public class PatientDetailServiceImpl implements PatientDetailService {

	@Autowired
	PatientDetailRepo patientDetailRepo;
	@Override
	public PatientDetails saveDetails(PatientDetails patientDetails) {
 //	patientDetailRepo.save(patientDetails);
		return patientDetailRepo.save(patientDetails);
	}

	public PatientDetails getPatientDetails(Long patientId) {
		PatientDetails list =   patientDetailRepo.findByPatientId(patientId);
		//List<PatientDetails> setdata = new new list
		 
		  return list;
		
	}

	@Override
	public PatientDetails findByPatientId(Long patientId) {
		PatientDetails list =   patientDetailRepo.findByPatientId(patientId);

		return list;
	}

	@Override
	public List<Map<String, Object>> getpatientdata(String patientNo) {
		 List<Object[]> list = patientDetailRepo.getPatientData(patientNo);
		 
		 List<Map<String, Object>> patientDataList = new ArrayList<>();
	        for (Object[] row : list) {
	            Map<String, Object> patientData = new HashMap<>();
	            patientData.put("patient_id", row[0]);
	            patientData.put("patient_no", row[1]);
	            patientData.put("mobile_no", row[2]);
	            patientData.put("dist_name", row[3]);
	            patientData.put("invoice_amount", row[4]);
	            patientData.put("invoice_date", row[5]);
	            patientDataList.add(patientData);
	        }
		return patientDataList;
	}

	/*
	 * @Override public PatientDetails updateby(Long patientId) { PatientDetails
	 * bean = patientDetailRepo.updateby(patientId); return bean; }
	 */

	 
}

package com.sp.serviceImpl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sp.entity.InvoiceMaster;
import com.sp.repository.InvoiceBillRepo;
import com.sp.service.InvoiceBillService;

@Service
public class InvoiceBillServiceImpl implements InvoiceBillService {

	@Autowired
	InvoiceBillRepo invoiceBillRepo;
	
	@Override
	@Transactional
 	public  InvoiceMaster getbilldata(String invoiceNo) {
		  InvoiceMaster  list = invoiceBillRepo.findByInvoiceNo(invoiceNo);
			/*
			 * InvoiceMaster master = new InvoiceMaster();
			 * master.setInvoiceId(list.getInvoiceId());
			 * master.setInvoiceNo(list.get(0).getInvoiceNo());
			 * master.setInvoiceAmount(list.get(0).getInvoiceAmount());
			 * master.setInvoiceDate(list.get(0).getInvoiceDate());
			 * master.setInvoiceRemark(list.get(0).getInvoiceRemark());
			 * master.setUnitId(list.get(0).getUnitId());
			 * master.setStatus(list.get(0).getStatus());
			 * master.setCreatedDate(list.get(0).getCreatedDate());
			 * master.setUpdatedDate(list.get(0).getUpdatedDate());
			 * master.setDistName(list.get(0).getDistName());
			 */
		 return list;
	}

	 

	@Override
	public List<InvoiceMaster> findAll( ) {
		List<InvoiceMaster> list= invoiceBillRepo.findAll();
		return list;

	}
	
    public InvoiceMaster saveInvoice(InvoiceMaster invoiceMaster) {
    	 
    	InvoiceMaster invoice = new InvoiceMaster();
    	invoice.setDistName(invoiceMaster.getDistName());
    	invoice.setInvoiceAmount(invoiceMaster.getInvoiceAmount());
        invoice.setInvoiceNo(invoiceMaster.getInvoiceNo());
        invoice.setStatus(invoiceMaster.getStatus());
        invoice.setUnitId(invoiceMaster.getUnitId());
        invoice.setInvoiceRemark(invoiceMaster.getInvoiceRemark());
        invoice.setInvoiceDate(LocalDateTime.now());
        invoice.setCreatedDate(LocalDateTime.now());
        invoice.setUpdatedDate(LocalDateTime.now());
        
         return invoiceBillRepo.save(invoice);
    }


}
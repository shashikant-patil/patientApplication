package com.sp.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sp.entity.HospitalDetails;
import com.sp.repository.HospitalDetailsRepo;
import com.sp.service.HospitalDetailsService;

@Service
public class HospitalDetailsServiceImpl implements HospitalDetailsService {

	@Autowired
	HospitalDetailsRepo repo;
	
	
	@Override
	public HospitalDetails savehospital(HospitalDetails hospitalDetails) {
 		return repo.save(hospitalDetails);
	}

}

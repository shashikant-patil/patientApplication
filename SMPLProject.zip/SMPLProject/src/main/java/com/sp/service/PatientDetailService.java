package com.sp.service;

 
import java.util.List;
import java.util.Map;

import com.sp.beans.PatientDetailBean;
import com.sp.entity.PatientDetails;

public interface PatientDetailService {

	PatientDetails saveDetails(PatientDetails patientDetails);
	
	PatientDetails findByPatientId(Long patientId);
	
//	List<PatientDetailBean> getpatientdata(String patientNo);
	 public List<Map<String, Object>> getpatientdata(String patientNo);
	 
 	// PatientDetails updateby(Long patientId);
  }

package com.sp.service;

import com.sp.entity.AmbulancePatient;

public interface AmbulanceDetailService {

	AmbulancePatient savedata(AmbulancePatient ambulancePatient);
}

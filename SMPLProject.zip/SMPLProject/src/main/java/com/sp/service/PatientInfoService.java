package com.sp.service;

import java.util.List;
import java.util.Map;

import com.sp.beans.PatientDetailBean;
 import com.sp.entity.PatientDetails;

public interface PatientInfoService {

	public Iterable<PatientDetails> getAllPatient();
	
	//PatientDetails  savePatient(Map<String, Object>  patientDetails);

 	public List<PatientDetailBean> getdata();
 	
 	public PatientDetails  getbypatientId(Long patientId);
 	
 	PatientDetails  savePatient(PatientDetails patientDetails);
 	
 	PatientDetails updatePatient(PatientDetails patientDetails);

}

package com.sp.service;

public interface DoctorDetailService {

}

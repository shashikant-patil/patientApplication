package com.sp.service;

public class DoctorDetailServiceImpl {

}

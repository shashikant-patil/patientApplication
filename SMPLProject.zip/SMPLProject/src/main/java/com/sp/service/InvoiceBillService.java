package com.sp.service;

 
import java.util.List;
import java.util.Optional;

import com.sp.entity.InvoiceMaster;

public interface InvoiceBillService {
	
	 InvoiceMaster getbilldata(String invoiceNo);
	//Optional<InvoiceMaster> getbilldata(Integer invoiceNo);

	 InvoiceMaster  saveInvoice(InvoiceMaster  invoiceMaster);
	List<InvoiceMaster> findAll();


}

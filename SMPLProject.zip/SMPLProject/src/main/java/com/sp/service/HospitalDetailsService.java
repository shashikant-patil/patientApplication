package com.sp.service;

import com.sp.entity.HospitalDetails;

public interface HospitalDetailsService {

	HospitalDetails savehospital(HospitalDetails hospitalDetails);
}

package com.sp.repository;

import org.springframework.data.repository.CrudRepository;

import com.sp.entity.HospitalDetails;

public interface HospitalDetailsRepo extends  CrudRepository<HospitalDetails,Integer>{

}

package com.sp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sp.beans.PatientDetailBean;
import com.sp.entity.PatientDetails;

@Repository
public interface PatientDetailRepo extends JpaRepository<PatientDetails, Long>{
   
	//PatientDetails findById(Long patientId);
	@Query("SELECT sp FROM PatientDetails sp WHERE sp.patientId= :patientId")
	PatientDetails findByPatientId(@Param("patientId") Long patientId);

	
	  @Query(value="select "+ 
	  " a.patient_id,a.patient_no,a.mobile_no,a.dist_name, "+
	  " b.invoice_amount,b.invoice_date "+ 
	  " from t2t_test.patient_detials a "+
	  " JOIN t2t_test.invoice_master b ON a.patient_id=b.patient_id "+
	  " where a.patient_no=:patientNo ",
	  nativeQuery = true)
	  List<Object[]>  getPatientData(@Param("patientNo") String patientNo);
	 
	   
	//  PatientDetails updateby(Long patientId);
	/*
	 * @Query("SELECT new com.sp.dto.PatientDetailBean(" +
	 * "a.patient_id, a.patient_no, a.mobile_no, a.dist_name, " +
	 * "b.invoice_amount, b.invoice_date) " + "FROM t2t_test.patient_detials a " +
	 * "JOIN t2t_test.invoice_master b ON a.patient_id = b.patient_id " +
	 * "WHERE a.patient_no = :patientNo") List<PatientDetailBean>
	 * getPatientData(@Param("patientNo") String patientNo);
	 */
}

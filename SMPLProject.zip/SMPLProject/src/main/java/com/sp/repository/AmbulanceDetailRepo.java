package com.sp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sp.entity.AmbulancePatient;

public interface AmbulanceDetailRepo extends JpaRepository<AmbulancePatient,Integer> {

}

package com.sp.repository;

 import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sp.entity.PatientDetails;

//public interface PatientInfoRepo extends CrudRepository<PatientDetails, Long> {
public interface PatientInfoRepo extends  JpaRepository<PatientDetails, Long> {

	//void saves(PatientDetails patientDetails);
	 // List<PatientDetails> findbypatientId(Long patientId);
	  @Query("SELECT p FROM PatientDetails p WHERE p.patientId = :patientId")
	  PatientDetails findPatientById(@Param("patientId") Long patientId);
 }

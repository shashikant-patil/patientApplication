 // Event listener for button click to submit the form
document.getElementById('savePatientBtn').addEventListener('click', function(event) {
    event.preventDefault(); // Prevent form submission

    // Get the form data
    const formData = new FormData(document.querySelector('form'));
    const data = Object.fromEntries(formData.entries()); // Convert FormData to an object

    // Send the data to the controller
    fetch('/patientinfo/savepatient', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data), // Send form data as JSON
    })
    .then(response => {
        if (response.ok) {
            // Redirect or display a success message after successful submission
            window.location.href = "/patientinfo/patientForm";
        } else {
            console.error('Failed to save patient details');
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});
